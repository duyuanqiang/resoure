# Day06 作业布置

## 一. 完成课堂所有的代码





## 二. 写出盒子模型包含的内容以及如何设置





## 三. 说说你对margin的传递和折叠的理解





## 四. 行内非替换元素在设置padding/border的上下时，有什么特殊的地方？





## 五. 整理box-sizing的作用，以及content-box和border-box的区别





## 六. 说出元素水平居中的方案以及对应的场景





## 七. 练习background-position和background-size（为精灵图做准备）





## 八. 找出三个盒子模型的综合案例进行练习