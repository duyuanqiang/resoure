import React, { memo } from 'react'

export default memo(function HYPlayerComment() {
  return (
    <div>
      
    </div>
  )
})
