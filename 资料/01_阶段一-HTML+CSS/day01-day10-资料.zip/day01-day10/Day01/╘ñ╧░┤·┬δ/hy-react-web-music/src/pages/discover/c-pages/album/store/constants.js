export const CHANGE_HOT_ALBUMS = "ablum/CHANGE_HOT_ALBUMS";
export const CHANGE_TOP_ALBUMS = "album/CHANGE_TOP_ALBUMS";
export const CHANGE_TOP_TOTAL = "album/CHANGE_TOP_TOTAL";
