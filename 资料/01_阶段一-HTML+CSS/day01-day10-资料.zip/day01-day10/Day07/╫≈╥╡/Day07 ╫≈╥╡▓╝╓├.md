# Day07 作业布置

## 一. 完成课堂所有的代码





## 二. 自己查一个列表并且完成





## 三. 完成table的作业内容

![作业](https://tva1.sinaimg.cn/large/e6c9d24egy1h0vps9hqn6j21cb0j0di4.jpg)



## 四. 说出表单元素什么情况下使用name和value？





## 五. 说出form提交时的属性作用

* action
* method
* target







