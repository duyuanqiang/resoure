# QQ音乐规范

### 统一使用flex布局

### 统一使用Less预处理器

### 默认进行SEO优化

* title 加上text-indent
* h元素 等等

### 使用语义化元素

* header
* nav
* section
* footer
* 等等

### 尽量使用封装思想

### Class类名推荐

* header
* top
* nav
* section-*
* banner
* first-title一级标签
* second-title二级标签
* btn,button
* footer
* desc描述
* icon
* icon-type

